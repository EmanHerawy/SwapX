// @generated
pub mod contract {
    // @@protoc_insertion_point(attribute:contract.v1)
    pub mod v1 {
        include!("contract.v1.rs");
        // @@protoc_insertion_point(contract.v1)
    }
}
